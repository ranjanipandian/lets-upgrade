#write a program that takes 2 inputs frm the user in variable a and b.based on these on these inputs find the output of the following expresions
#1.Floor Division
#2.a power b
#3.find out whether two variables have equal value or not - if yes then print True if thesy are not equalthen print False


a=int(input("Enter the first number:"))
b=int(input("Enter the second number:"))
print("The Floor Division is\n",a//b);
print("The power of the two numbers is\n",a**b);
if a==b:
    print("True")
else:
    print("False")