#write a program that takes side of a square as input and calculates the area of this square by using area() function.
def area(a):
    return(a*a)

a=int(input("Enter the side of the square:"))
print(area(a))
